import { MenuEntry } from '@mozartfinance/uikit'

const config: MenuEntry[] = [
  {
    label: 'Home',
    icon: 'HomeIcon',
    href: 'http://akinoswap.app/',
  },
  {
    label: 'Trade',
    icon: 'TradeIcon',
    items: [
      {
        label: 'Exchange',
        href: '/swap',
      },
      {
        label: 'Liquidity',
        href: '/pool',
      },
    ],
  },
  {
    label: 'Premium Listing',
    icon: 'TicketIcon',
    href: '',
  },
  /*
  {
    label: 'Pools',
    icon: 'PoolIcon',
    href: '',
  },
  {
    label: 'More',
    icon: 'MoreIcon',
    items: [
      {
        label: 'Telegram',
        href: 'https://t.me/akinoinu',
      },
      {
        label: 'Whitepaper',
        href: 'https://drive.google.com/file/d/1xJiCrzfp9Cl2LIrUFtMPCEguFmTsppNE/view?usp=sharing',
      },
      {
        label: 'Blog',
        href: 'https://akinoinu.medium.com/',
      },
    ],
  },
  {
    label: 'Audit by TECHAUDIT',
    icon: 'TicketIcon',
    href: 'https://github.com/Tech-Audit/Smart-Contract-Audits/blob/main/TECHAUDIT_AKINO%20INU.pdf',
  }, */
]

export default config
